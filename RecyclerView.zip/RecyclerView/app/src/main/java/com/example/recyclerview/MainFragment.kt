package com.example.recyclerview


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recyclerview.data.User
import kotlinx.android.synthetic.main.fragment_main.view.*

/**
 * A simple [Fragment] subclass.
 */
class MainFragment : Fragment() {

    val users = mutableListOf<User>()
    private var adapter : MyUserRecyclerViewAdapter? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_main, container, false)

        users.add(User("User1", "Mail1", "Phone1"))
        users.add(User("User2", "Mail2", "Phone2"))
        users.add(User("User3", "Mail3", "Phone3"))
        users.add(User("User4", "Mail4", "Phone4"))
        users.add(User("User5", "Mail5", "Phone5"))
        users.add(User("User6", "Mail6", "Phone6"))
        users.add(User("User7", "Mail7", "Phone7"))
        users.add(User("User8", "Mail8", "Phone8"))
        users.add(User("User9", "Mail9", "Phone9"))
        users.add(User("User10", "Mail10", "Phone10"))
        users.add(User("User11", "Mail11", "Phone11"))
        users.add(User("User12", "Mail12", "Phone12"))
        users.add(User("User13", "Mail13", "Phone13"))
        users.add(User("User14", "Mail14", "Phone14"))
        users.add(User("User15", "Mail15", "Phone15"))
        users.add(User("User16", "Mail16", "Phone16"))
        users.add(User("User17", "Mail17", "Phone17"))
        users.add(User("User18", "Mail18", "Phone18"))
        users.add(User("User19", "Mail19", "Phone19"))
        users.add(User("User20", "Mail20", "Phone20"))

        adapter = MyUserRecyclerViewAdapter(users)

        view.list.layoutManager = LinearLayoutManager(context)
        view.list.adapter = adapter

        return view
    }


}
