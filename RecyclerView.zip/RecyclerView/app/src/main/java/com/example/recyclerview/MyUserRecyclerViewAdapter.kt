package com.example.recyclerview

import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview.data.User
import kotlinx.android.synthetic.main.row.view.*

class MyUserRecyclerViewAdapter(private val mValues: List<User>) : RecyclerView.Adapter<MyUserRecyclerViewAdapter.ViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyUserRecyclerViewAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.row, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = mValues.size

    override fun onBindViewHolder(holder: MyUserRecyclerViewAdapter.ViewHolder, position: Int) {
        val item = mValues[position]
        holder.textViewName.text = item.nombre
        holder.textViewMail.text = item.mail
        holder.textViewPhone.text = item.phone
    }

    inner class ViewHolder(val mView: View) : RecyclerView.ViewHolder(mView){
        val textViewName : TextView = mView.textViewName
        val textViewMail : TextView = mView.textViewMail
        val textViewPhone : TextView = mView.textViewPhone
    }

}